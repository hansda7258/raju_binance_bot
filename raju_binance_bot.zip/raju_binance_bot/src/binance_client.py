import os
from binance.client import Client
from dotenv import load_dotenv


load_dotenv()
API_KEY = os.getenv('GoyuZxs8C4WdF0UZnDkycoJq03jDBgEZ5e5IbwA4Q92kIn2PrDMc3C7Gmpie035J')
API_SECRET = os.getenv('CE4Dx7EQYIDbE3KQJmX9cYkgkw9ETwuY2Yi78nRQKJtAEG1Go8d0CNJilVBEtUVm')
USE_TESTNET = os.getenv('https://testnet.binance.vision/', 'false').lower() in ('1','true','yes')


_client = None


def get_client():
global _client
if _client:
return _client
if USE_TESTNET:
# Testnet base URL for futures (if using python-binance you may need to set testnet url)
_client = Client(API_KEY, API_SECRET, testnet=True)
else:
_client = Client(API_KEY, API_SECRET)
return _client