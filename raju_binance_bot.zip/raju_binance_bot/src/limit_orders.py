from src.logger import setup_logger
from src.binance_client import get_client
from src.validation import validate_symbol, validate_quantity, validate_price


logger = setup_logger('limit_orders')


def place_limit_order(symbol: str, side: str, quantity: float, price: float, time_in_force='GTC'):
symbol = validate_symbol(symbol)
quantity = validate_quantity(quantity)
price = validate_price(price)
client = get_client()
try:
logger.info('Placing LIMIT order: %s %s %s @ %s', side, symbol, quantity, price)
res = client.futures_create_order(
symbol=symbol,
side=side,
type='LIMIT',
timeInForce=time_in_force,
quantity=quantity,
price=str(price)
)
logger.info('Order response: %s', res)
return res
except Exception as e:
logger.exception('Failed to place limit order: %s', e)
raise