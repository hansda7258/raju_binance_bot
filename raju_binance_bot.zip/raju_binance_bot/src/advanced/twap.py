import time
from src.logger import setup_logger
from src.market_orders import place_market_order
logger = setup_logger('twap')


def run_twap(symbol, side, total_qty, slices=5, interval_s=60):
per_slice = total_qty / slices
logger.info('Running TWAP: %s slices=%s per_slice=%s', symbol, slices, per_slice)
results = []
for i in range(slices):
res = place_market_order(symbol, side, per_slice)
results.append(res)
time.sleep(interval_s)
return results