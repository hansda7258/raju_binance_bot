from src.logger import setup_logger
logger = setup_logger('oco')


def place_oco(symbol, side, quantity, tp_price, sl_price):
logger.info('OCO placeholder: %s %s qty=%s tp=%s sl=%s', symbol, side, quantity, tp_price, sl_price)
# Real implementation should create two orders and cancel the other when one fills.
raise NotImplementedError('OCO not implemented yet')