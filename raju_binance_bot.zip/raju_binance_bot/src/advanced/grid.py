from src.logger import setup_logger
logger = setup_logger('grid')


def run_grid(symbol, lower, upper, steps, size):
logger.info('Grid placeholder: %s %s-%s steps=%s size=%s', symbol, lower, upper, steps, size)
raise NotImplementedError('Grid strategy not implemented yet')