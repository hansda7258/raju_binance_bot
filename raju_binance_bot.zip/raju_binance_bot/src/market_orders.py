from src.logger import setup_logger
from src.binance_client import get_client
from src.validation import validate_symbol, validate_quantity


logger = setup_logger('market_orders')


def place_market_order(symbol: str, side: str, quantity: float):
symbol = validate_symbol(symbol)
quantity = validate_quantity(quantity)
client = get_client()
try:
logger.info('Placing MARKET order: %s %s %s', side, symbol, quantity)
res = client.futures_create_order(
symbol=symbol,
side=side,
type='MARKET',
quantity=quantity
)
logger.info('Order response: %s', res)
return res
except Exception as e:
logger.exception('Failed to place market order: %s', e)
raise