import argparse
p_market.add_argument('--side', required=True, choices=['BUY','SELL'])
p_market.add_argument('--quantity', required=True, type=float)


# limit
p_limit = subparsers.add_parser('limit')
p_limit.add_argument('--symbol', required=True)
p_limit.add_argument('--side', required=True, choices=['BUY','SELL'])
p_limit.add_argument('--quantity', required=True, type=float)
p_limit.add_argument('--price', required=True, type=float)


args = parser.parse_args()


if args.command == 'market':
market_orders.place_market_order(symbol=args.symbol, side=args.side, quantity=args.quantity)
elif args.command == 'limit':
limit_orders.place_limit_order(symbol=args.symbol, side=args.side, quantity=args.quantity, price=args.price)
else:
parser.print_help()