from src.logger import setup_logger
logger = setup_logger('validation')


def validate_symbol(symbol: str):
if not symbol.isalnum():
logger.error('Invalid symbol format: %s', symbol)
raise ValueError('Invalid symbol')
return symbol.upper()


def validate_quantity(qty: float):
if qty <= 0:
logger.error('Quantity must be positive')
raise ValueError('Quantity must be positive')
return round(qty, 8)


def validate_price(price: float):
if price <= 0:
logger.error('Price must be positive')
raise ValueError('Price must be positive')
return price